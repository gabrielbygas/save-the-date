<?php $__env->startSection('content'); ?>
<div class="max-w-2xl mx-auto p-6 bg-white shadow rounded-xl mt-8">
    <h1 class="text-2xl font-bold mb-4">Passer une commande Save The Date</h1>

    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-700 p-3 mb-4 rounded"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 text-red-800 p-4 mb-4 rounded">
            <ul class="list-disc pl-5 space-y-1">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__errorArgs = ['photos.0'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-500 text-sm mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </ul>
        </div>
    <?php endif; ?>


    <form action="<?php echo e(route('order.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block">Prénom (Monsieur) *</label>
                <input type="text" name="mr_first_name" class="w-full border p-2 rounded" value="<?php echo e(old('mr_first_name')); ?>" required>
            </div>
            <div>
                <label class="block">Nom (Monsieur) *</label>
                <input type="text" name="mr_last_name" class="w-full border p-2 rounded" value="<?php echo e(old('mr_last_name')); ?>" required>
            </div>
        </div>

        
        <div class="grid grid-cols-2 gap-4 mt-4">
            <div>
                <label class="block">Prénom (Madame) *</label>
                <input type="text" name="mrs_first_name" class="w-full border p-2 rounded" value="<?php echo e(old('mrs_first_name')); ?>" required>
            </div>
            <div>
                <label class="block">Nom (Madame) *</label>
                <input type="text" name="mrs_last_name" class="w-full border p-2 rounded" value="<?php echo e(old('mrs_last_name')); ?>" required>
            </div>
        </div>

        <label class="block mt-4">Email *</label>
        <input type="email" name="email" class="w-full border p-2 rounded" value="<?php echo e(old('email')); ?>" required>

        <label class="block mt-4">Numéro Whatsapp *</label>
        <input type="text" name="phone" class="w-full border p-2 rounded" value="<?php echo e(old('phone')); ?>" required>

        <label class="block mt-4">Date du mariage *</label>
        <input type="date" name="wedding_date" class="w-full border p-2 rounded" value="<?php echo e(old('wedding_date')); ?>" required>

        <label class="block mt-4">Lieu du mariage *</label>
        <input type="text" name="wedding_location" class="w-full border p-2 rounded" value="<?php echo e(old('wedding_location')); ?>" required>

        
        <label class="block mt-4">Pack *</label>
        <select name="pack_id" class="w-full border p-2 rounded" required>
            <?php $__currentLoopData = $packs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($pack->id); ?>" <?php echo e(old('pack_id') == $pack->id ? 'selected' : ''); ?>><?php echo e($pack->name); ?> - <?php echo e(number_format($pack->price, 2)); ?>$</option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label class="block mt-4">Thème *</label>
        <select name="theme_id" class="w-full border p-2 rounded">
            <option value="">-- Aucun --</option>
            <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($theme->id); ?>" <?php echo e(old('theme_id') == $theme->id ? 'selected' : ''); ?>><?php echo e($theme->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        
        <label class="block mt-4">Medias (JPG/PNG max 2Mo, MP4/MOV max 20Mo, max 5 fichiers)</label>
        <input type="file" name="photos[]" multiple class="w-full border p-2 rounded" accept="image/jpeg,image/png,video/mp4,video/mov,video/ogg">
        <p class="text-sm text-gray-500 mt-1">Vous pouvez télécharger jusqu'à 5 fichiers au total, avec un maximum de 10 Mo par fichier.</p>

        

        <!-- Case à cocher pour acceptation des CGU -->
        <div class="mb-4 mt-6">
            <label class="flex items-center space-x-2">
                <input type="checkbox" name="terms" required class="form-checkbox text-indigo-600" 
                       <?php echo e(old('terms') ? 'checked' : ''); ?>>
                <span class="text-sm">
                    J'accepte les <a href="<?php echo e(route('terms')); ?>" target="_blank" class="text-blue-600 underline">Conditions Générales d'Utilisation</a>
                </span>
            </label>
        </div>

        <button type="submit" class="mt-6 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
            Envoyer la commande
        </button>
    </form>
</div>


<script>
document.addEventListener('DOMContentLoaded', function () {
    const fileInput = document.querySelector('input[name="photos[]"]');

    fileInput.addEventListener('change', function () {
        const files = Array.from(fileInput.files);
        const maxFiles = 5;
        const allowedTypes = ['image/jpeg', 'image/png', 'video/mp4', 'video/mov', 'video/ogg'];
        const maxSize = 10 * 1024 * 20240; // 20MB

        // Vérifie le nombre de fichiers
        if (files.length > maxFiles) {
            alert(`Vous ne pouvez sélectionner que ${maxFiles} fichiers.`);
            fileInput.value = ''; // Annule la sélection
            return;
        }

        // Vérifie chaque fichier
        for (let file of files) {
            if (!allowedTypes.includes(file.type)) {
                alert(`Fichier non autorisé : ${file.name}`);
                fileInput.value = '';
                return;
            }
            if (file.size > maxSize) {
                alert(`Fichier trop volumineux (${file.name}) : max 10 Mo.`);
                fileInput.value = '';
                return;
            }
        }

    });
});
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/save-the-date/resources/views/order/create.blade.php ENDPATH**/ ?>